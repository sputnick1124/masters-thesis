clear all
clc

%Fuzzy logic controller:
Kp = readfis('Kp7.fis');
Kd = readfis('Kd7.fis');
Ki = readfis('Ki7.fis');

sim('KFUZZapp10');
sim('KFUZZappdeg10');
sim('KFUZZsubsonic10');
sim('KFUZZsupersonic10');

load('pid_pitch1.mat');
load('pid_pitch2.mat');
load('pid_pitch3.mat');
load('pid_pitch4.mat');

figure(1);
plot(thetapid_APP(1,1:1001),thetapid_APP(2,1:1001));
title('Fuzzy PID - Approach Condition');
grid on;
zoom;

figure(2);
plot(thetapid_APPDEG(1,1:1001),thetapid_APPDEG(2,1:1001));
title('Fuzzy PID - Degraded Approach Condition');
grid on;

figure(3);
plot(thetapid_SUB(1,1:1001),thetapid_SUB(2,1:1001));
title('Fuzzy PID - Subsonic Cruise Condition');
grid on;

figure(4);
plot(thetapid_SUPER(1,1:1001),thetapid_SUPER(2,1:1001));
title('Fuzzy PID - Supersonic Cruise Condition');
grid on;
